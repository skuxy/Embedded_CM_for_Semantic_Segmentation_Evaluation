import os
import pickle
import numpy as np
import tensorflow as tf
import skimage as ski
import skimage.data
import skimage.transform
from tqdm import trange
from PIL import Image
import matplotlib.pyplot as plt

FLAGS = tf.app.flags.FLAGS

tf.app.flags.DEFINE_integer('cx_start', 0, '')
tf.app.flags.DEFINE_integer('cx_end', 2048, '')
tf.app.flags.DEFINE_integer('cy_start', 0, '')
tf.app.flags.DEFINE_integer('cy_end', 1024, '')

tf.app.flags.DEFINE_integer('img_width', 512, '')
tf.app.flags.DEFINE_integer('img_height', 256, '')

def resizeMostCommonClass(gt_ids, downscale = 2):
	cx_start = FLAGS.cx_start
	cx_end = FLAGS.cx_end
	cy_start = FLAGS.cy_start
	cy_end = FLAGS.cy_end
	gt_ids = np.ascontiguousarray(gt_ids[cy_start:cy_end,cx_start:cx_end])
	myNp = np.asarray([np.argmax(np.bincount(np.ravel(np.ascontiguousarray(gt_ids[i:i+downscale, j:j+downscale])))) 
		for i in range(cy_start, cy_end, downscale) for j in range(cx_start, cx_end, downscale)])
	myNp = np.reshape(myNp, (FLAGS.img_height, FLAGS.img_width)).astype(np.uint8)
	return myNp

	#import pdb
	#pdb.set_trace()	
	


def main(argv):
	cx_start = FLAGS.cx_start
	cx_end = FLAGS.cx_end
	cy_start = FLAGS.cy_start
	cy_end = FLAGS.cy_end


	'''rgb_path = '/home/stjepan/FAKS/zavrad/tTf/aachen_000015_000019.ppm'
	rgb = ski.data.load(rgb_path)
	rgb = np.ascontiguousarray(rgb[cy_start:cy_end,cx_start:cx_end,:])
	rgb = ski.transform.resize( rgb, (FLAGS.img_height, FLAGS.img_width), preserve_range=True, order=3)
	rgb = rgb.astype(np.uint8)'''
	#ski.io.imsave('/home/stjepan/FAKS/zavrad/tTf/rgb_img.png', rgb)

	#rgb = ski.transform.pyramid_reduce(rgb, downscale=4.0, order = 3)
	#ski.io.imsave('/home/stjepan/FAKS/zavrad/tTf/rgb_pyrReduce_img.png', rgb)


	#gt_path = '/home/stjepan/FAKS/zavrad/tTf/aachen_000015_000019.pickle'
	gt_path = 'aachen_000015_000019.pickle'
	with open(gt_path, 'rb') as f:
		gt_data = pickle.load(f)
	gt_ids = gt_data[0]
	gt_ids = np.ascontiguousarray(gt_ids[cy_start:cy_end,cx_start:cx_end])
	gt_ids = resizeMostCommonClass(gt_ids, 4).astype(np.uint8)
	#ski.io.imsave('/home/stjepan/FAKS/zavrad/tTf/mostCommonTry1.png', gt_ids)
	ski.io.imsave('mostCommonTry2.png', gt_ids)
	exit()

	#gt_weights = gt_data[1]
	'''num_labels = gt_data[2]
	class_weights = gt_data[4]
	assert num_labels == (gt_ids < 255).sum()
	gt_ids = np.ascontiguousarray(gt_ids[cy_start:cy_end,cx_start:cx_end])
	gt_ids = ski.transform.resize(gt_ids, (FLAGS.img_height, FLAGS.img_width), order=0, preserve_range=True).astype(np.uint8)
	gt_ids = gt_ids.astype(np.int8)
	ski.io.imsave('/home/stjepan/FAKS/zavrad/tTf/gt_img.png', gt_ids)
	gt_weights = np.zeros((FLAGS.img_height, FLAGS.img_width), np.float32)
	for i, wgt in enumerate(class_weights):
		gt_weights[gt_ids == i] = wgt'''


if __name__ == '__main__':
  tf.app.run()
  main()